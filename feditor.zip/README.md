# Visual Workflow Builder 3 Prototype

This is a code bundle for Visual Workflow Builder 3 Prototype.

## Running the code

Run `npm i` to install the dependencies.

Run `npm run dev` to start the development server.