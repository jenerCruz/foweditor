import VisualWorkflowBuilder3 from "./pages/VisualWorkflowBuilder3";

function App() {
  return <VisualWorkflowBuilder3 />;
}

export default App;